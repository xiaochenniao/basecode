/**
 * Created by pc on 2017/3/3.
 */

$(function(){

    new Swiper ('#swiper1', {
        paginationClickable: true,
        loop: true,
        spaceBetween: 20,
        centeredSlides: true,
        autoplay: 2500,

        // �����Ҫǰ�����˰�ť
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',

    })

    new Swiper('#swiper2', {
        paginationClickable: true,
        loop: true,
        spaceBetween: 20,
        centeredSlides: true,
        autoplay: 2500,
    });

})
